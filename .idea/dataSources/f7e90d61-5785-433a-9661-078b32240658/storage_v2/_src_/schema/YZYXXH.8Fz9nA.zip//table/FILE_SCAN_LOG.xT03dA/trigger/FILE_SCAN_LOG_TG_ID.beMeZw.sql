create trigger FILE_SCAN_LOG_TG_ID
  before insert
  on FILE_SCAN_LOG
  for each row
begin
select file_scan_log_sq_id.nextval into:new.id from dual;
end;
/

