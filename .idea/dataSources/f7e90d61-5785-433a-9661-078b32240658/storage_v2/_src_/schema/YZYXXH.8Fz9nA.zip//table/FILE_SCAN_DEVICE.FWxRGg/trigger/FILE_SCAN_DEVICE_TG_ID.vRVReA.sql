create trigger FILE_SCAN_DEVICE_TG_ID
  before insert
  on FILE_SCAN_DEVICE
  for each row
begin
select file_scan_device_sq_id.nextval into:new.id from dual;
end;
/

